//
//  SmartCropperWrapper.h
//  SmartCropper-iOS
//
//  Created by linus on 2020/8/15.
//  Copyright © 2020 linusling. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SmartCropperWrapper : NSObject

/// current OpenCV version
+ (NSString *)openCVVersionString;

/// initialize image detector using tensorflow
+ (void)initImageDetector;

/// scan input image, then return 4 crop points sorted by leftTop, rightTop, rightBottom, leftBottom
/// @param inputImage inputImage
+ (NSArray *)scanWithOpenCV:(UIImage *)inputImage;

/// crop input image with 4 crop points, then return the cropped image
/// @param inputImage inputImage
/// @param points 4 crop points sorted by leftTop, rightTop, rightBottom, leftBottom
+ (UIImage *)cropWithOpenCV:(UIImage *)inputImage points:(NSArray *)points;

@end

NS_ASSUME_NONNULL_END
